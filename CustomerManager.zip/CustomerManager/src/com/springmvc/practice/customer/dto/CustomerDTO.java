package com.springmvc.practice.customer.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class CustomerDTO {

	private Long id;

	@NotEmpty
	@Size(min = 6, max = 10, message = "Your name must between 4 and 10 characters.")
	private String name;
	@NotEmpty
	@Email
	private String email;
	@NotEmpty
	private String address;

	public CustomerDTO() {
	}

	public CustomerDTO(Long id, String name, String email, String address) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.address = address;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
