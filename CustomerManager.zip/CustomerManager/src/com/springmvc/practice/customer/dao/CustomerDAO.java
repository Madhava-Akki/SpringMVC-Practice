package com.springmvc.practice.customer.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.springmvc.practice.customer.dto.CustomerDTO;

@Repository
public class CustomerDAO {
	private static final Map<Long, CustomerDTO> customerDetailsMap = new HashMap<>();

	static {
		initEmps();
	}

	private static void initEmps() {
		CustomerDTO customer1 = new CustomerDTO(1001l, "Sathya Nadella", "microsoftceo@gmail.com", "USA");
		CustomerDTO customer2 = new CustomerDTO(1002l, "Sundarpichai", "googleceo@gmail.com", "USA");
		CustomerDTO customer3 = new CustomerDTO(1003l, "Ratan TATA", "tataceo@gmail.com", "INDIA");

		customerDetailsMap.put(customer1.getId(), customer1);
		customerDetailsMap.put(customer2.getId(), customer2);
		customerDetailsMap.put(customer3.getId(), customer3);
	}

	public void save(CustomerDTO customer) {
		customerDetailsMap.put(customer.getId(), customer);
	}

	public List<CustomerDTO> listAll() {
		Collection<CustomerDTO> customerDetails = customerDetailsMap.values();
		List<CustomerDTO> list = new ArrayList<>();
		list.addAll(customerDetails);
		return list;
	}

	public CustomerDTO get(Long id) {
		return customerDetailsMap.get(id);
	}

	public void delete(Long id) {
		if (customerDetailsMap.containsKey(id))
			customerDetailsMap.remove(id);
	}

	public List<CustomerDTO> search(Long keyword) {
		List<CustomerDTO> list = new ArrayList<>();
		if (customerDetailsMap.containsKey(keyword))
			list.add(customerDetailsMap.get(keyword));
		return list;
	}

}
