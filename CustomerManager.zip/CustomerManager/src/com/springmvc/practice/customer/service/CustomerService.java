package com.springmvc.practice.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.springmvc.practice.customer.dao.CustomerDAO;
import com.springmvc.practice.customer.dto.CustomerDTO;

@Service
public class CustomerService {

	@Autowired
	CustomerDAO repo;

	public void save(CustomerDTO customer) {
		repo.save(customer);
	}

	public List<CustomerDTO> listAll() {
		return repo.listAll();
	}

	public CustomerDTO get(Long id) {
		return repo.get(id);
	}

	public void delete(Long id) {
		repo.delete(id);
	}

	public List<CustomerDTO> search(Long keyword) {
		return repo.search(keyword);
	}
}
