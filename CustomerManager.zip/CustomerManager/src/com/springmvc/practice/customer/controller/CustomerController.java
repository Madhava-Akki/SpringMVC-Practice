package com.springmvc.practice.customer.controller;

import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.practice.customer.dto.CustomerDTO;
import com.springmvc.practice.customer.service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@GetMapping("/")
	public ModelAndView home() {
		List<CustomerDTO> listCustomer = customerService.listAll();
		ModelAndView mav = new ModelAndView("index");
		mav.addObject("listCustomer", listCustomer);
		return mav;
	}

	@GetMapping("/new")
	public String newCustomerForm(Map<String, Object> model) {
		CustomerDTO customer = new CustomerDTO();
		model.put("customer", customer);
		return "new_customer";
	}

	@PostMapping(value = "/save")
	public String saveCustomer(@Valid @ModelAttribute("customer") CustomerDTO customer, BindingResult result) {
		if (result.hasErrors()) {
			return "new_customer";
		} else {
			Random rnd = new Random();
			Long number = Long.valueOf(rnd.nextInt(99999));
			if (customer.getId() == null || customer.getId() <= 0)
				customer.setId(number);
			customerService.save(customer);
			return "redirect:/";
		}
	}

	@RequestMapping("/edit")
	public ModelAndView editCustomerForm(@RequestParam long id) {
		ModelAndView mav = new ModelAndView("edit_customer");
		CustomerDTO customer = customerService.get(id);
		mav.addObject("customer", customer);
		return mav;
	}

	@RequestMapping("/delete")
	public String deleteCustomerForm(@RequestParam long id) {
		customerService.delete(id);
		return "redirect:/";
	}

	@RequestMapping("/search")
	public String search(@RequestParam Long keyword, Model model) {
		List<CustomerDTO> result = customerService.search(keyword);
		model.addAttribute("result", result);
		return "search";
	}
}
