package com.student.usecase.service;

import org.springframework.stereotype.Service;

@Service
public class StudentService {

}
