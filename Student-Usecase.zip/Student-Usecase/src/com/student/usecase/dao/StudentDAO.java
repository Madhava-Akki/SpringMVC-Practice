package com.student.usecase.dao;

import org.springframework.stereotype.Repository;

@Repository
public class StudentDAO {
	

}
